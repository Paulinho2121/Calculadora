﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Bot0 = New System.Windows.Forms.Button()
        Me.Bot2 = New System.Windows.Forms.Button()
        Me.Bot3 = New System.Windows.Forms.Button()
        Me.Bot1 = New System.Windows.Forms.Button()
        Me.Bot4 = New System.Windows.Forms.Button()
        Me.Bot7 = New System.Windows.Forms.Button()
        Me.Bot8 = New System.Windows.Forms.Button()
        Me.Bot5 = New System.Windows.Forms.Button()
        Me.Bot9 = New System.Windows.Forms.Button()
        Me.Bot6 = New System.Windows.Forms.Button()
        Me.BotMultiplicar = New System.Windows.Forms.Button()
        Me.BotSubtrair = New System.Windows.Forms.Button()
        Me.BotSomar = New System.Windows.Forms.Button()
        Me.BotCalcular = New System.Windows.Forms.Button()
        Me.BotDividir = New System.Windows.Forms.Button()
        Me.BotBackspace = New System.Windows.Forms.Button()
        Me.Resultado = New System.Windows.Forms.TextBox()
        Me.txtNumero1 = New System.Windows.Forms.TextBox()
        Me.txtOP = New System.Windows.Forms.TextBox()
        Me.botPonto = New System.Windows.Forms.Button()
        Me.botClean = New System.Windows.Forms.Button()
        Me.botInverter = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Bot0
        '
        Me.Bot0.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot0.Location = New System.Drawing.Point(103, 347)
        Me.Bot0.Name = "Bot0"
        Me.Bot0.Size = New System.Drawing.Size(75, 59)
        Me.Bot0.TabIndex = 1
        Me.Bot0.Text = "0"
        Me.Bot0.UseVisualStyleBackColor = True
        '
        'Bot2
        '
        Me.Bot2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot2.Location = New System.Drawing.Point(103, 282)
        Me.Bot2.Name = "Bot2"
        Me.Bot2.Size = New System.Drawing.Size(75, 59)
        Me.Bot2.TabIndex = 2
        Me.Bot2.Text = "2"
        Me.Bot2.UseVisualStyleBackColor = True
        '
        'Bot3
        '
        Me.Bot3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot3.Location = New System.Drawing.Point(184, 282)
        Me.Bot3.Name = "Bot3"
        Me.Bot3.Size = New System.Drawing.Size(75, 59)
        Me.Bot3.TabIndex = 3
        Me.Bot3.Text = "3"
        Me.Bot3.UseVisualStyleBackColor = True
        '
        'Bot1
        '
        Me.Bot1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot1.Location = New System.Drawing.Point(22, 282)
        Me.Bot1.Name = "Bot1"
        Me.Bot1.Size = New System.Drawing.Size(75, 59)
        Me.Bot1.TabIndex = 4
        Me.Bot1.Text = "1"
        Me.Bot1.UseVisualStyleBackColor = True
        '
        'Bot4
        '
        Me.Bot4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot4.Location = New System.Drawing.Point(22, 217)
        Me.Bot4.Name = "Bot4"
        Me.Bot4.Size = New System.Drawing.Size(75, 59)
        Me.Bot4.TabIndex = 5
        Me.Bot4.Text = "4"
        Me.Bot4.UseVisualStyleBackColor = True
        '
        'Bot7
        '
        Me.Bot7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot7.Location = New System.Drawing.Point(22, 152)
        Me.Bot7.Name = "Bot7"
        Me.Bot7.Size = New System.Drawing.Size(75, 59)
        Me.Bot7.TabIndex = 6
        Me.Bot7.Text = "7"
        Me.Bot7.UseVisualStyleBackColor = True
        '
        'Bot8
        '
        Me.Bot8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot8.Location = New System.Drawing.Point(103, 152)
        Me.Bot8.Name = "Bot8"
        Me.Bot8.Size = New System.Drawing.Size(75, 59)
        Me.Bot8.TabIndex = 7
        Me.Bot8.Text = "8"
        Me.Bot8.UseVisualStyleBackColor = True
        '
        'Bot5
        '
        Me.Bot5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot5.Location = New System.Drawing.Point(103, 217)
        Me.Bot5.Name = "Bot5"
        Me.Bot5.Size = New System.Drawing.Size(75, 59)
        Me.Bot5.TabIndex = 8
        Me.Bot5.Text = "5"
        Me.Bot5.UseVisualStyleBackColor = True
        '
        'Bot9
        '
        Me.Bot9.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot9.Location = New System.Drawing.Point(184, 152)
        Me.Bot9.Name = "Bot9"
        Me.Bot9.Size = New System.Drawing.Size(75, 59)
        Me.Bot9.TabIndex = 9
        Me.Bot9.Text = "9"
        Me.Bot9.UseVisualStyleBackColor = True
        '
        'Bot6
        '
        Me.Bot6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bot6.Location = New System.Drawing.Point(184, 217)
        Me.Bot6.Name = "Bot6"
        Me.Bot6.Size = New System.Drawing.Size(75, 59)
        Me.Bot6.TabIndex = 10
        Me.Bot6.Text = "6"
        Me.Bot6.UseVisualStyleBackColor = True
        '
        'BotMultiplicar
        '
        Me.BotMultiplicar.BackColor = System.Drawing.Color.Green
        Me.BotMultiplicar.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotMultiplicar.Location = New System.Drawing.Point(279, 156)
        Me.BotMultiplicar.Name = "BotMultiplicar"
        Me.BotMultiplicar.Size = New System.Drawing.Size(70, 59)
        Me.BotMultiplicar.TabIndex = 11
        Me.BotMultiplicar.Text = "x"
        Me.BotMultiplicar.UseVisualStyleBackColor = False
        '
        'BotSubtrair
        '
        Me.BotSubtrair.BackColor = System.Drawing.Color.Green
        Me.BotSubtrair.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotSubtrair.Location = New System.Drawing.Point(279, 221)
        Me.BotSubtrair.Name = "BotSubtrair"
        Me.BotSubtrair.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BotSubtrair.Size = New System.Drawing.Size(70, 59)
        Me.BotSubtrair.TabIndex = 12
        Me.BotSubtrair.Text = "-"
        Me.BotSubtrair.UseVisualStyleBackColor = False
        '
        'BotSomar
        '
        Me.BotSomar.BackColor = System.Drawing.Color.Green
        Me.BotSomar.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotSomar.Location = New System.Drawing.Point(279, 286)
        Me.BotSomar.Name = "BotSomar"
        Me.BotSomar.Size = New System.Drawing.Size(70, 59)
        Me.BotSomar.TabIndex = 13
        Me.BotSomar.Text = "+"
        Me.BotSomar.UseVisualStyleBackColor = False
        '
        'BotCalcular
        '
        Me.BotCalcular.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.BotCalcular.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotCalcular.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.BotCalcular.Location = New System.Drawing.Point(279, 351)
        Me.BotCalcular.Name = "BotCalcular"
        Me.BotCalcular.Size = New System.Drawing.Size(70, 59)
        Me.BotCalcular.TabIndex = 14
        Me.BotCalcular.Text = "="
        Me.BotCalcular.UseVisualStyleBackColor = False
        '
        'BotDividir
        '
        Me.BotDividir.BackColor = System.Drawing.Color.Green
        Me.BotDividir.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotDividir.Location = New System.Drawing.Point(279, 91)
        Me.BotDividir.Name = "BotDividir"
        Me.BotDividir.Size = New System.Drawing.Size(70, 59)
        Me.BotDividir.TabIndex = 15
        Me.BotDividir.Text = "/"
        Me.BotDividir.UseVisualStyleBackColor = False
        '
        'BotBackspace
        '
        Me.BotBackspace.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotBackspace.Location = New System.Drawing.Point(22, 347)
        Me.BotBackspace.Name = "BotBackspace"
        Me.BotBackspace.Size = New System.Drawing.Size(75, 59)
        Me.BotBackspace.TabIndex = 16
        Me.BotBackspace.Text = "<-"
        Me.BotBackspace.UseVisualStyleBackColor = True
        '
        'Resultado
        '
        Me.Resultado.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Resultado.Location = New System.Drawing.Point(22, 47)
        Me.Resultado.Name = "Resultado"
        Me.Resultado.Size = New System.Drawing.Size(327, 29)
        Me.Resultado.TabIndex = 17
        Me.Resultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtNumero1
        '
        Me.txtNumero1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNumero1.Location = New System.Drawing.Point(22, 12)
        Me.txtNumero1.Name = "txtNumero1"
        Me.txtNumero1.Size = New System.Drawing.Size(276, 29)
        Me.txtNumero1.TabIndex = 18
        Me.txtNumero1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtOP
        '
        Me.txtOP.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOP.Location = New System.Drawing.Point(308, 12)
        Me.txtOP.Name = "txtOP"
        Me.txtOP.Size = New System.Drawing.Size(41, 29)
        Me.txtOP.TabIndex = 19
        Me.txtOP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'botPonto
        '
        Me.botPonto.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botPonto.Location = New System.Drawing.Point(185, 351)
        Me.botPonto.Name = "botPonto"
        Me.botPonto.Size = New System.Drawing.Size(75, 55)
        Me.botPonto.TabIndex = 20
        Me.botPonto.Text = "."
        Me.botPonto.UseVisualStyleBackColor = True
        '
        'botClean
        '
        Me.botClean.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botClean.Location = New System.Drawing.Point(185, 91)
        Me.botClean.Name = "botClean"
        Me.botClean.Size = New System.Drawing.Size(75, 55)
        Me.botClean.TabIndex = 21
        Me.botClean.Text = "C"
        Me.botClean.UseVisualStyleBackColor = True
        '
        'botInverter
        '
        Me.botInverter.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botInverter.Location = New System.Drawing.Point(103, 91)
        Me.botInverter.Name = "botInverter"
        Me.botInverter.Size = New System.Drawing.Size(75, 55)
        Me.botInverter.TabIndex = 22
        Me.botInverter.Text = "+/-"
        Me.botInverter.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(362, 418)
        Me.Controls.Add(Me.botInverter)
        Me.Controls.Add(Me.botClean)
        Me.Controls.Add(Me.botPonto)
        Me.Controls.Add(Me.txtOP)
        Me.Controls.Add(Me.txtNumero1)
        Me.Controls.Add(Me.Resultado)
        Me.Controls.Add(Me.BotBackspace)
        Me.Controls.Add(Me.BotDividir)
        Me.Controls.Add(Me.BotCalcular)
        Me.Controls.Add(Me.BotSomar)
        Me.Controls.Add(Me.BotSubtrair)
        Me.Controls.Add(Me.BotMultiplicar)
        Me.Controls.Add(Me.Bot6)
        Me.Controls.Add(Me.Bot9)
        Me.Controls.Add(Me.Bot5)
        Me.Controls.Add(Me.Bot8)
        Me.Controls.Add(Me.Bot7)
        Me.Controls.Add(Me.Bot4)
        Me.Controls.Add(Me.Bot1)
        Me.Controls.Add(Me.Bot3)
        Me.Controls.Add(Me.Bot2)
        Me.Controls.Add(Me.Bot0)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Bot0 As Button
    Friend WithEvents Bot2 As Button
    Friend WithEvents Bot3 As Button
    Friend WithEvents Bot1 As Button
    Friend WithEvents Bot4 As Button
    Friend WithEvents Bot7 As Button
    Friend WithEvents Bot8 As Button
    Friend WithEvents Bot5 As Button
    Friend WithEvents Bot9 As Button
    Friend WithEvents Bot6 As Button
    Friend WithEvents BotMultiplicar As Button
    Friend WithEvents BotSubtrair As Button
    Friend WithEvents BotSomar As Button
    Friend WithEvents BotCalcular As Button
    Friend WithEvents BotDividir As Button
    Friend WithEvents BotBackspace As Button
    Friend WithEvents Resultado As TextBox
    Friend WithEvents txtNumero1 As TextBox
    Friend WithEvents txtOP As TextBox
    Friend WithEvents botPonto As Button
    Friend WithEvents botClean As Button
    Friend WithEvents botInverter As Button
End Class
